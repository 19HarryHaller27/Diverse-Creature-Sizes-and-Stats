================================================================================
FOR CAWSOME — "Diverse Creature Sizes and Stats" / Mutations (ModDB #47726)
================================================================================

WHAT YOU ASKED FOR (in the ModDB thread)
----------------------------------------
You wanted a way to tune how big or small mutated creatures can get — a
config so you can avoid "gigantic monsters" if you prefer, or dial limits
to your taste. That is exactly "min/max limits for size" (the mod author
Squidbat also mentioned wanting to push past 75% growth; engine limits can
still apply for extreme values — start conservative).

WHAT IS IN THIS FOLDER
-----------------------
1) Mutations_to_install\
   - Mutations.dll
   - modinfo.json
   Put these inside:  VintagestoryData\Mods\Mutations\
   (Create the "Mutations" folder if needed. Same layout as a normal mod.)

2) ModConfig_sample\mutations.json
   This file does NOT go inside Mods. Copy it to:
      VintagestoryData\ModConfig\mutations.json
   (The "ModConfig" folder sits next to "Mods" under VintagestoryData.)

   After the mod runs once on the server, the game may already create
   mutations.json there — you can edit those values and restart the server.

CONFIG KEYS (JSON)
------------------
MinMutationScale  — smallest applied size multiplier (default 0.5 = 50% of normal)
MaxMutationScale  — largest applied size multiplier (default 1.75 = +75% vs normal)

Example to cap growth so nothing goes above "normal" size:
   "MaxMutationScale": 1.0

Example to allow only mild variation:
   "MinMutationScale": 0.85,
   "MaxMutationScale": 1.15

Official mod page (context + comments):
https://mods.vintagestory.at/show/mod/47726

Vintage Story mod config docs:
https://wiki.vintagestory.at/Modding:ModConfig

================================================================================
Package prepared for handoff — not an official ModDB upload by itself.
================================================================================
